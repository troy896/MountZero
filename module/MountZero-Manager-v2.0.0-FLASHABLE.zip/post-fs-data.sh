#!/system/bin/sh
# MountZero VFS - Post-FS-Data Script
# This runs AFTER metamount.sh has completed the mount pipeline.
# Handles bootloop guard recording and ADB root setup.

MODDIR="${0%/*}"

# Record post-fs-data execution for bootloop detection
echo 1 > /data/adb/mountzero/.bootcount 2>/dev/null

# Enable MountZero VFS (safety net if metamount.sh didn't)
/data/adb/ksu/bin/mzctl enable 2>/dev/null

# Create bind mount markers for /data/local/ modules
for moddir in /data/local/*/; do
    [ -d "$moddir" ] || continue
    MODID=$(basename "$moddir")
    case "$MODID" in
        lost+found|tmp|media|oem|vendor|system|tests|traces) continue ;;
    esac
    mount --bind "$moddir" "$moddir" 2>/dev/null
done

exit 0
