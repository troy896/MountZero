(function() {
  'use strict';

  /* ============================================================
   * MountZero VFS - WebUI Controller
   * Uses kernelsu.js exec() Promise-based API
   * ============================================================ */

  const MZCTL = '/data/adb/ksu/bin/mzctl';
  const KSU_SUSFS = '/data/adb/ksu/bin/ksu_susfs';
  let isLoaded = false;

  /* ============================================================
   * Command Runner
   * ============================================================ */

  async function runCmd(cmd) {
    try {
      if (typeof exec === 'function') {
        const result = await exec(cmd, {});
        return (result.stdout || '') + (result.stderr || '');
      } else if (typeof ksu !== 'undefined' && typeof ksu.exec === 'function') {
        return new Promise((resolve) => {
          const cbName = 'mzcb_' + Date.now();
          window[cbName] = (errno, stdout, stderr) => {
            resolve((stdout || '') + (stderr || ''));
            delete window[cbName];
          };
          ksu.exec(cmd, '{}', cbName);
        });
      }
    } catch (e) {
      return 'Error: ' + e.message;
    }
    return 'KernelSU bridge not available';
  }

  async function runMZ(args) {
    return await runCmd(`${MZCTL} ${args} 2>&1`);
  }

  /* ============================================================
   * Tab Navigation
   * ============================================================ */

  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const tabId = 'tab-' + tab.dataset.tab;
      document.getElementById(tabId).classList.add('active');

      switch (tab.dataset.tab) {
        case 'status': loadStatus(); break;
        case 'modules': loadModules(); break;
        case 'rules': loadRules(); break;
        case 'config': loadConfig(); break;
        case 'guard': loadGuard(); break;
        case 'tools': break;
      }
    });
  });

  /* ============================================================
   * Status Tab
   * ============================================================ */

  async function loadStatus() {
    try {
      var status = await runMZ('status');
      var isEnabled = status.indexOf('ENABLED') !== -1;
      var badge = document.getElementById('status-badge');
      badge.textContent = isEnabled ? 'Active' : 'Inactive';
      badge.className = 'badge ' + (isEnabled ? 'active' : 'inactive');

      var rulesOutput = await runMZ('list');
      var ruleLines = rulesOutput.split('\n').filter(function(l) { return l.indexOf('REDIRECT:') === 0; });
      var uniqueRules = new Set(ruleLines);
      var ruleCount = uniqueRules.size;

      document.getElementById('engine-status').textContent = isEnabled ? 'ENABLED' : 'DISABLED';

      // Get SUSFS version
      var susfsVer = await runCmd('/data/adb/ksu/bin/ksu_susfs show version 2>/dev/null || echo --');
      document.getElementById('engine-driver').textContent = susfsVer.trim() || '--';

      document.getElementById('engine-rules').textContent = String(ruleCount);
      document.getElementById('engine-hidden').textContent = String(ruleLines.length);
      document.getElementById('engine-maps').textContent = String(ruleLines.length);
      document.getElementById('engine-uids').textContent = '0';

      var kernel = (await runCmd('uname -r 2>/dev/null')).trim();
      var android = (await runCmd('getprop ro.build.version.release 2>/dev/null')).trim();
      var device = (await runCmd('getprop ro.product.model 2>/dev/null')).trim();
      var uptimeRaw = (await runCmd('cat /proc/uptime 2>/dev/null')).trim();
      var uptimeSec = parseFloat(uptimeRaw.split(' ')[0]) || 0;
      var uptimeHrs = Math.floor(uptimeSec / 3600);
      var uptimeMin = Math.floor((uptimeSec % 3600) / 60);

      document.getElementById('info-kernel').textContent = kernel || 'Unknown';
      document.getElementById('info-android').textContent = android || 'Unknown';
      document.getElementById('info-device').textContent = device || 'Unknown';
      document.getElementById('info-uptime').textContent = uptimeHrs + 'h ' + uptimeMin + 'm';

      var selinux = (await runCmd('getenforce 2>/dev/null')).trim();
      var selinuxEl = document.getElementById('info-selinux');
      selinuxEl.textContent = selinux || 'Unknown';
      selinuxEl.style.color = selinux === 'Enforcing' ? '#f85149' : '#3fb950';

      var detect = await runMZ('detect');
      var capVfs = detect.indexOf('VFS driver:     AVAILABLE') !== -1 ? 'Available' : 'Not Available';
      var capSusfs = detect.indexOf('SUSFS:          AVAILABLE') !== -1 ? 'Available' : 'Not Available';
      var capOverlay = detect.indexOf('OverlayFS:      AVAILABLE') !== -1 ? 'Available' : 'Not Available';
      var capErofs = detect.indexOf('EROFS:          AVAILABLE') !== -1 ? 'Available' : 'Not Available';

      document.getElementById('cap-vfs').textContent = capVfs;
      document.getElementById('cap-vfs').style.color = capVfs === 'Available' ? '#3fb950' : '#f85149';
      document.getElementById('cap-susfs').textContent = capSusfs;
      document.getElementById('cap-susfs').style.color = capSusfs === 'Available' ? '#3fb950' : '#f85149';
      document.getElementById('cap-overlay').textContent = capOverlay;
      document.getElementById('cap-overlay').style.color = capOverlay === 'Available' ? '#3fb950' : '#f85149';
      document.getElementById('cap-erofs').textContent = capErofs;
      document.getElementById('cap-erofs').style.color = capErofs === 'Available' ? '#3fb950' : '#f85149';
    } catch (e) {
      console.error('loadStatus error: ' + e);
      document.getElementById('engine-status').textContent = 'ERROR';
    }
  }

  document.getElementById('btn-refresh').addEventListener('click', loadStatus);
  document.getElementById('btn-enable-vfs').addEventListener('click', async () => {
    const result = await runMZ('enable');
    showToast(result.trim());
    loadStatus();
  });
  document.getElementById('btn-disable-vfs').addEventListener('click', async () => {
    const result = await runMZ('disable');
    showToast(result.trim());
    loadStatus();
  });

  /* ============================================================
   * Modules Tab
   * ============================================================ */

  async function loadModules() {
    const output = await runCmd('ls -1 /data/adb/modules/ 2>/dev/null');
    const list = document.getElementById('module-list');
    list.innerHTML = '';

    if (!output || output.includes('Permission denied') || output.includes('inaccessible') || output.trim() === '') {
      list.innerHTML = '<div class="list-item"><span class="path">No modules found or no access</span></div>';
      return;
    }

    const modules = output.trim().split('\n').filter(m => m);
    for (const mod of modules) {
      const item = document.createElement('div');
      item.className = 'list-item';

      const disableCheck = await runCmd(`test -f /data/adb/modules/${mod}/disable && echo disabled || echo active`);
      const isActive = !disableCheck.includes('disabled');

      const nameProp = (await runCmd(`grep '^name=' /data/adb/modules/${mod}/module.prop 2>/dev/null | cut -d= -f2`)).trim();
      const modName = nameProp || mod;

      item.innerHTML = `
        <span class="path">${modName}</span>
        <span class="status ${isActive ? 'active' : 'disabled'}">${isActive ? 'Active' : 'Disabled'}</span>
      `;
      list.appendChild(item);
    }
  }

  document.getElementById('module-search').addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    document.querySelectorAll('#module-list .list-item').forEach(item => {
      const text = item.querySelector('.path').textContent.toLowerCase();
      item.style.display = text.includes(query) ? '' : 'none';
    });
  });

  /* ============================================================
   * VFS Rules Tab
   * ============================================================ */

  async function loadRules() {
    const output = await runMZ('list');
    const list = document.getElementById('rule-list');
    list.innerHTML = '';

    const lines = output.split('\n').filter(l => l.startsWith('REDIRECT:'));
    if (lines.length === 0) {
      list.innerHTML = '<div class="list-item"><span class="path">No active rules</span></div>';
      return;
    }

    // Deduplicate rules
    const seen = new Set();
    const uniqueLines = lines.filter(line => {
      if (seen.has(line)) return false;
      seen.add(line);
      return true;
    });

    uniqueLines.forEach(line => {
      const match = line.match(/REDIRECT:\s+(.+?)\s+->\s+(.+)/);
      if (!match) return;

      const item = document.createElement('div');
      item.className = 'list-item';
      item.innerHTML = `
        <div>
          <div class="path">${match[1]}</div>
          <div class="path" style="color: var(--text-secondary); font-size: 0.75rem;">→ ${match[2]}</div>
        </div>
        <button class="btn-del" data-virt="${match[1]}">Del</button>
      `;
      list.appendChild(item);
    });

    // Add delete handlers
    list.querySelectorAll('.btn-del').forEach(btn => {
      btn.addEventListener('click', async () => {
        const virt = btn.dataset.virt;
        const result = await runMZ(`del "${virt}"`);
        showToast(result.trim());
        loadRules();
      });
    });
  }

  document.getElementById('btn-add-rule').addEventListener('click', async () => {
    const virt = document.getElementById('rule-virt').value.trim();
    const real = document.getElementById('rule-real').value.trim();
    if (!virt || !real) {
      showToast('Both paths are required');
      return;
    }
    const result = await runMZ(`add "${virt}" "${real}"`);
    showToast(result.trim());
    document.getElementById('rule-virt').value = '';
    document.getElementById('rule-real').value = '';
    loadRules();
  });

  document.getElementById('btn-clear-rules').addEventListener('click', async () => {
    if (!confirm('Clear all VFS rules?')) return;
    const result = await runMZ('clear');
    showToast(result.trim());
    loadRules();
  });

  /* ============================================================
   * Config Tab
   * ============================================================ */

  async function loadConfig() {
    const config = await runCmd('cat /data/adb/mountzero/config.toml 2>/dev/null');
    if (config && !config.includes('No such file')) {
      // Parse partitions
      const partMatch = config.match(/partitions\s*=\s*\[(.+?)\]/);
      if (partMatch) {
        document.getElementById('cfg-partitions').value = partMatch[1].replace(/"/g, '').replace(/\s/g, '');
      }
    }
  }

  document.getElementById('btn-apply-config').addEventListener('click', async () => {
    let results = [];

    const paths = document.getElementById('cfg-hidden-paths').value.trim().split('\n').filter(p => p);
    for (const path of paths) {
      results.push(await runMZ(`susfs add-path "${path.trim()}"`));
    }

    const maps = document.getElementById('cfg-hidden-maps').value.trim().split('\n').filter(m => m);
    for (const map of maps) {
      results.push(await runMZ(`susfs add-map "${map.trim()}"`));
    }

    const release = document.getElementById('cfg-uname-release').value.trim();
    const version = document.getElementById('cfg-uname-version').value.trim();
    if (release && version) {
      results.push(await runMZ(`susfs set-uname "${release}" "${version}"`));
    }

    const successCount = results.filter(r => !r.includes('Error')).length;
    showToast(successCount + ' settings applied');
    loadStatus();
  });

  document.getElementById('btn-save-config').addEventListener('click', async () => {
    const partitions = document.getElementById('cfg-partitions').value.trim();
    const selinuxSpoof = document.getElementById('cfg-selinux-spoof').checked;
    const hideMounts = document.getElementById('cfg-hide-mounts').checked;
    const adbRoot = document.getElementById('cfg-adb-root').checked;

    const parts = partitions.split(',').map(p => `"${p.trim()}"`).filter(p => p !== '""').join(', ');
    const config = `[mount]\nmountEngine = "vfs"\npartitions = [${parts}]\nselinux_spoof = ${selinuxSpoof}\nhide_mounts = ${hideMounts}\n\n[adb]\nroot = ${adbRoot}\n`;

    await runCmd(`mkdir -p /data/adb/mountzero && echo '${config}' > /data/adb/mountzero/config.toml`);
    showToast('Config saved');
  });

  document.getElementById('btn-reset-config').addEventListener('click', () => {
    document.getElementById('cfg-partitions').value = 'product, system_ext, vendor';
    document.getElementById('cfg-selinux-spoof').checked = true;
    document.getElementById('cfg-hide-mounts').checked = true;
    document.getElementById('cfg-adb-root').checked = false;
    showToast('Config reset to defaults');
  });

  document.getElementById('btn-apply-adb').addEventListener('click', async () => {
    const enabled = document.getElementById('cfg-adb-root').checked;
    await runCmd(`mkdir -p /data/adb/mountzero && echo ${enabled ? 'true' : 'false'} > /data/adb/mountzero/adb_root`);
    showToast('ADB root setting ' + (enabled ? 'enabled' : 'disabled'));
  });

  /* ============================================================
   * Guard Tab
   * ============================================================ */

  async function loadGuard() {
    const output = await runMZ('guard check');
    const lines = output.split('\n');
    lines.forEach(line => {
      const m = line.match(/Boot count:\s+(\d+)/);
      if (m) {
        const count = parseInt(m[1]);
        document.getElementById('guard-count').textContent = count;
        const status = count >= 3 ? 'TRIPPED' : 'OK';
        document.getElementById('guard-status').textContent = status;
        document.getElementById('guard-status').style.color = status === 'TRIPPED' ? '#f85149' : '#3fb950';
      }
      const m2 = line.match(/Threshold:\s+(\d+)/);
      if (m2) document.getElementById('guard-threshold').textContent = m2[1];
    });
  }

  document.getElementById('btn-check-guard').addEventListener('click', loadGuard);
  document.getElementById('btn-recover-guard').addEventListener('click', async () => {
    const result = await runMZ('guard recover');
    showToast(result.trim());
    loadGuard();
  });

  /* ============================================================
   * Tools Tab
   * ============================================================ */

  document.getElementById('btn-detect').addEventListener('click', async () => {
    const output = await runMZ('detect');
    document.getElementById('detect-output').textContent = output;
  });

  document.getElementById('btn-dump').addEventListener('click', async () => {
    showToast('Creating diagnostic dump...');
    const output = await runMZ('dump');
    document.getElementById('detect-output').textContent = output;
  });

  document.getElementById('btn-install-module').addEventListener('click', async () => {
    const modId = document.getElementById('tool-mod-id').value.trim();
    const modPath = document.getElementById('tool-mod-path').value.trim();
    const isCustom = document.getElementById('tool-mod-custom').checked;

    if (!modId || !modPath) {
      showToast('Module ID and path are required');
      return;
    }

    const args = isCustom
      ? `module install "${modId}" "${modPath}" custom`
      : `module install "${modId}" "${modPath}"`;
    const result = await runMZ(args);
    showToast(result.trim());
  });

  document.getElementById('btn-scan-modules').addEventListener('click', async () => {
    showToast('Scanning all modules...');
    const output = await runMZ('module scan');
    document.getElementById('detect-output').textContent = output;
    loadRules();
    loadStatus();
  });

  /* ============================================================
   * Toast Notification
   * ============================================================ */

  function showToast(message) {
    if (typeof ksu !== 'undefined' && typeof ksu.toast === 'function') {
      ksu.toast(message);
    } else {
      const toast = document.createElement('div');
      toast.style.cssText = 'position:fixed;bottom:60px;left:50%;transform:translateX(-50%);background:var(--accent);color:#000;padding:8px 16px;border-radius:8px;font-size:0.85rem;font-weight:500;z-index:9999;transition:opacity 0.3s;';
      toast.textContent = message;
      document.body.appendChild(toast);
      setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
      }, 2000);
    }
  }

  /* ============================================================
   * Initial Load
   * ============================================================ */

  loadStatus();
  isLoaded = true;

})();
