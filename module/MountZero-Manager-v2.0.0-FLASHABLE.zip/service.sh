#!/system/bin/sh
# MountZero VFS - Service Script (Hot-plug daemon + overlay unmount watcher)
# Runs after boot-complete. Watches for new/removed modules.

MODDIR="${0%/*}"
MZCTL="/data/adb/ksu/bin/mzctl"
CONFIG_DIR="/data/adb/mountzero"
CONFIG_SH="$MODDIR/config.sh"
BRIDGE_SH="$MODDIR/bridge.sh"
CONFIG_FILE="$CONFIG_DIR/config.toml"
WORK_BASE="/dev/mountzero_work"
UPPER_BASE="/dev/mountzero_upper"

# Wait for boot to complete
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# Ensure MountZero is enabled
$MZCTL enable 2>/dev/null

# Reset boot counter after successful boot
echo 0 > "$CONFIG_DIR/.bootcount" 2>/dev/null

# Reconcile external SUSFS configs on boot
if [ -x "$BRIDGE_SH" ]; then
    "$BRIDGE_SH" reconcile all 2>/dev/null
    "$BRIDGE_SH" write "$CONFIG_FILE" 2>/dev/null
fi

# Handle ADB root
ADB_ROOT_ENABLED=$("$CONFIG_SH" get adb adbRoot false 2>/dev/null)
if [ "$ADB_ROOT_ENABLED" = "true" ] && [ -x "$MODDIR/axon.sh" ]; then
    "$MODDIR/axon.sh" enable 2>/dev/null
fi

# Function: Unmount a module's overlay partitions
unmount_module_overlays() {
    local modid="$1"

    grep "mountzero_${modid}_" /proc/mounts 2>/dev/null | while read -r line; do
        local mp
        mp=$(echo "$line" | awk '{print $2}')
        umount -l "$mp" 2>/dev/null
        echo "MountZero: unmounted overlay: $mp ($modid)" > /dev/kmsg 2>/dev/null
    done

    # Clean work/upper dirs
    rm -rf "${WORK_BASE}/${modid}_"* 2>/dev/null
    rm -rf "${UPPER_BASE}/${modid}_"* 2>/dev/null
}

# Track currently mounted modules for change detection
PREV_MODULES=$(ls -1 /data/adb/modules/ 2>/dev/null | sort)

# Hot-plug auto-detection daemon
while true; do
    # Detect newly installed modules
    CURR_MODULES=$(ls -1 /data/adb/modules/ 2>/dev/null | sort)

    # Find new modules
    for modid in $CURR_MODULES; do
        case "$modid" in
            mountzero_vfs|meta-mountzero_vfs) continue ;;
        esac

        # Check if this is a new module
        if ! echo "$PREV_MODULES" | grep -qx "$modid"; then
            echo "MountZero: New module detected: $modid" > /dev/kmsg 2>/dev/null
            moddir="/data/adb/modules/$modid"

            if [ -d "$moddir" ] && [ ! -f "${moddir}disable" ] && [ ! -f "${moddir}remove" ]; then
                $MZCTL module install "$modid" "$moddir" 2>/dev/null

                # Mount overlay if partition exists
                for part in system vendor product system_ext odm; do
                    if [ -d "${moddir}${part}" ]; then
                        mkdir -p "${WORK_BASE}/${modid}_${part}_work" 2>/dev/null
                        mkdir -p "${UPPER_BASE}/${modid}_${part}_upper" 2>/dev/null
                        mount -t overlay "mountzero_${modid}_${part}" \
                            -o "lowerdir=${moddir}${part}:/${part},upperdir=${UPPER_BASE}/${modid}_${part}_upper,workdir=${WORK_BASE}/${modid}_${part}_work" \
                            "/${part}" 2>/dev/null
                    fi
                done
            fi
        fi
    done

    # Find removed modules
    for modid in $PREV_MODULES; do
        case "$modid" in
            mountzero_vfs|meta-mountzero_vfs) continue ;;
        esac

        if ! echo "$CURR_MODULES" | grep -qx "$modid"; then
            echo "MountZero: Module removed: $modid" > /dev/kmsg 2>/dev/null
            unmount_module_overlays "$modid"
            $MZCTL clear 2>/dev/null
        fi
    done

    # Check for modules_update (hot install)
    if [ -d "/data/adb/modules_update" ]; then
        for moddir in /data/adb/modules_update/*/; do
            [ -d "$moddir" ] || continue
            MODID=$(basename "$moddir")
            case "$MODID" in
                mountzero_vfs|meta-mountzero_vfs) continue ;;
            esac
            if [ ! -f "$CONFIG_DIR/.mz_installed_$MODID" ]; then
                echo "MountZero: Hot-plug installing module: $MODID" > /dev/kmsg 2>/dev/null
                $MZCTL module install "$MODID" "$moddir" 2>/dev/null
                touch "$CONFIG_DIR/.mz_installed_$MODID"
            fi
        done
    fi

    # Check for new custom modules in /data/local/
    for moddir in /data/local/*/; do
        [ -d "$moddir" ] || continue
        MODID=$(basename "$moddir")
        case "$MODID" in
            lost+found|tmp|media|oem|vendor|system|tests|traces) continue ;;
        esac
        if [ ! -f "$CONFIG_DIR/.mz_installed_$MODID" ]; then
            echo "MountZero: Hot-plug installing custom module: $MODID" > /dev/kmsg 2>/dev/null
            $MZCTL module install "$MODID" "$moddir" custom 2>/dev/null
            touch "$CONFIG_DIR/.mz_installed_$MODID"
        fi
    done

    PREV_MODULES="$CURR_MODULES"
    sleep 5
done
