#!/system/bin/sh
# MountZero VFS - SUSFS Hiding Engine (BRENE Integration)
# Provides root evasion: path hiding, maps hiding, prop spoofing, cmdline spoofing
# All features from BRENE integrated directly into MountZero

PERSISTENT_DIR="/data/adb/mountzero"
SUSFS_BIN="/data/adb/ksu/bin/susfs"
RESETPROP="/data/adb/ksu/bin/resetprop"
LOG_FILE="$PERSISTENT_DIR/logs.txt"

# Fallback to ksu_susfs if susfs not available
if [ ! -x "$SUSFS_BIN" ]; then
    SUSFS_BIN="/data/adb/ksu/bin/ksu_susfs"
fi

log() {
    echo "mountzero-hiding: $*" > /dev/kmsg 2>/dev/null
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE" 2>/dev/null
}

susfs_clone_perm() {
    local TO="$1"
    local FROM="$2"
    if [ -z "$TO" ] || [ -z "$FROM" ]; then
        return
    fi
    local CLONED_PERM_STRING
    CLONED_PERM_STRING=$(stat -c "%a %U %G" "$FROM" 2>/dev/null)
    if [ -n "$CLONED_PERM_STRING" ]; then
        set $CLONED_PERM_STRING
        chmod $1 "$TO" 2>/dev/null
        chown $2:$3 "$TO" 2>/dev/null
        busybox chcon --reference="$FROM" "$TO" 2>/dev/null
    fi
}

# ============================================================
# Phase 1: Path Hiding (sus_path)
# ============================================================

apply_sus_paths() {
    log "Applying SUSFS path hiding rules"

    # KSU/APatch paths
    susfs_add_path "/data/adb/ksu"
    susfs_add_path "/data/adb/ap"
    susfs_add_path "/data/adb/modules"
    susfs_add_path "/data/adb/modules_update"

    # Magisk paths
    susfs_add_path "/sbin/.magisk"
    susfs_add_path "/data/cache/magisk.log"
    susfs_add_path "/cache/recovery"

    # Common detection paths
    susfs_add_path "/data/local/tmp"
    susfs_add_path "/data/adb/mountzero"

    # Custom user-defined paths
    if [ -f "$PERSISTENT_DIR/custom_sus_path.txt" ]; then
        while IFS= read -r path; do
            path=$(echo "$path" | sed 's/#.*//' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
            [ -z "$path" ] && continue
            susfs_add_path "$path"
        done < "$PERSISTENT_DIR/custom_sus_path.txt"
    fi

    log "SUSFS path hiding applied"
}

susfs_add_path() {
    local path="$1"
    if [ -e "$path" ]; then
        $SUSFS_BIN add_sus_path "$path" 2>/dev/null && \
            log "[sus_path]: $path" || \
            log "[sus_path FAILED]: $path"
    fi
}

susfs_add_path_loop() {
    local path="$1"
    if [ -e "$path" ]; then
        $SUSFS_BIN add_sus_path_loop "$path" 2>/dev/null && \
            log "[sus_path_loop]: $path" || \
            log "[sus_path_loop FAILED]: $path"
    fi
}

# ============================================================
# Phase 2: Maps Hiding (sus_map)
# ============================================================

apply_sus_maps() {
    log "Applying SUSFS maps hiding rules"

    # Zygisk injection hiding
    susfs_add_map "/data/adb/modules/rezygisk/zygisk"
    susfs_add_map "/data/adb/modules/zygisk_lsposed"

    # Custom user-defined maps
    if [ -f "$PERSISTENT_DIR/custom_sus_map.txt" ]; then
        while IFS= read -r path; do
            path=$(echo "$path" | sed 's/#.*//' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
            [ -z "$path" ] && continue
            susfs_add_map "$path"
        done < "$PERSISTENT_DIR/custom_sus_map.txt"
    fi

    log "SUSFS maps hiding applied"
}

susfs_add_map() {
    local path="$1"
    if [ -e "$path" ]; then
        $SUSFS_BIN add_sus_map "$path" 2>/dev/null && \
            log "[sus_map]: $path" || \
            log "[sus_map FAILED]: $path"
    fi
}

# ============================================================
# Phase 3: Uname Spoofing
# ============================================================

apply_uname_spoofing() {
    log "Applying uname spoofing"

    local kernel_release
    local kernel_version

    kernel_release=$(uname -r | cut -d'-' -f1)
    kernel_version="#1 SMP PREEMPT $(${RESETPROP} ro.build.date 2>/dev/null)"

    $SUSFS_BIN set_uname "$kernel_release" "$kernel_version" 2>/dev/null && \
        log "[set_uname]: $kernel_release $kernel_version" || \
        log "[set_uname FAILED]"
}

# ============================================================
# Phase 4: Cmdline/Bootconfig Spoofing
# ============================================================

apply_cmdline_spoofing() {
    log "Applying cmdline/bootconfig spoofing"

    local susfs_variant
    susfs_variant=$($SUSFS_BIN show variant 2>/dev/null)

    if [ "$susfs_variant" = "GKI" ]; then
        local FAKE_BOOTCONFIG="$PERSISTENT_DIR/fake_bootconfig.txt"
        cat /proc/bootconfig > "$FAKE_BOOTCONFIG" 2>/dev/null
        sed -i 's/androidboot.warranty_bit = "1"/androidboot.warranty_bit = "0"/' "$FAKE_BOOTCONFIG" 2>/dev/null
        sed -i 's/androidboot.verifiedbootstate = "orange"/androidboot.verifiedbootstate = "green"/' "$FAKE_BOOTCONFIG" 2>/dev/null
        sed -i 's/androidboot.vbmeta.device_state = "unlocked"/androidboot.vbmeta.device_state = "locked"/' "$FAKE_BOOTCONFIG" 2>/dev/null
        $SUSFS_BIN set_cmdline_or_bootconfig "$FAKE_BOOTCONFIG" 2>/dev/null && \
            log "[set_cmdline]: bootconfig spoofed" || \
            log "[set_cmdline FAILED]"
    else
        local FAKE_CMDLINE="$PERSISTENT_DIR/fake_cmdline.txt"
        cat /proc/cmdline > "$FAKE_CMDLINE" 2>/dev/null
        sed -i 's/androidboot.warranty_bit=1/androidboot.warranty_bit=0/' "$FAKE_CMDLINE" 2>/dev/null
        sed -i 's/androidboot.verifiedbootstate=orange/androidboot.verifiedbootstate=green/' "$FAKE_CMDLINE" 2>/dev/null
        sed -i 's/androidboot.vbmeta.device_state=unlocked/androidboot.vbmeta.device_state=locked/' "$FAKE_CMDLINE" 2>/dev/null
        $SUSFS_BIN set_cmdline_or_bootconfig "$FAKE_CMDLINE" 2>/dev/null && \
            log "[set_cmdline]: cmdline spoofed" || \
            log "[set_cmdline FAILED]"
    fi
}

# ============================================================
# Phase 5: Mount Hiding
# ============================================================

apply_mount_hiding() {
    log "Applying mount hiding"

    # Hide SUSFS mounts from non-su processes
    $SUSFS_BIN hide_sus_mnts_for_non_su_procs 1 2>/dev/null && \
        log "[hide_mounts]: enabled for non-su processes" || \
        log "[hide_mounts FAILED]"
}

# ============================================================
# Phase 6: AVC Log Spoofing
# ============================================================

apply_avc_log_spoofing() {
    log "Applying AVC log spoofing"

    $SUSFS_BIN enable_avc_log_spoofing 1 2>/dev/null && \
        log "[avc_log_spoofing]: enabled" || \
        log "[avc_log_spoofing FAILED]"
}

# ============================================================
# Phase 7: Android System Properties Spoofing
# ============================================================

apply_prop_spoofing() {
    log "Applying Android system properties spoofing"

    # Basic security props
    $RESETPROP -n "ro.adb.secure" "1" 2>/dev/null
    $RESETPROP -n "ro.debuggable" "0" 2>/dev/null
    $RESETPROP -n "ro.secure" "1" 2>/dev/null
    $RESETPROP -n "ro.build.selinux" "1" 2>/dev/null
    $RESETPROP -n "ro.build.type" "user" 2>/dev/null
    $RESETPROP -n "ro.build.tags" "release-keys" 2>/dev/null
    $RESETPROP -n "ro.bootmode" "normal" 2>/dev/null
    $RESETPROP -n "ro.bootimage.build.tags" "release-keys" 2>/dev/null

    # Bootloader/verified boot props
    $RESETPROP -n "ro.boot.flash.locked" "1" 2>/dev/null
    $RESETPROP -n "ro.boot.verifiedbootstate" "green" 2>/dev/null
    $RESETPROP -n "ro.boot.vbmeta.device_state" "locked" 2>/dev/null
    $RESETPROP -n "ro.boot.veritymode" "enforcing" 2>/dev/null
    $RESETPROP -n "ro.boot.vbmeta.hash_alg" "sha256" 2>/dev/null
    $RESETPROP -n "ro.boot.vbmeta.avb_version" "1.3" 2>/dev/null
    $RESETPROP -n "ro.boot.vbmeta.invalidate_on_error" "yes" 2>/dev/null
    $RESETPROP -n "ro.is_ever_orange" "0" 2>/dev/null
    $RESETPROP -n "vendor.boot.vbmeta.device_state" "locked" 2>/dev/null
    $RESETPROP -n "vendor.boot.verifiedbootstate" "green" 2>/dev/null

    # Warranty props
    $RESETPROP -n "ro.warranty_bit" "0" 2>/dev/null
    $RESETPROP -n "ro.vendor.boot.warranty_bit" "0" 2>/dev/null
    $RESETPROP -n "ro.vendor.warranty_bit" "0" 2>/dev/null
    $RESETPROP -n "ro.boot.warranty_bit" "0" 2>/dev/null
    $RESETPROP -n "sys.oem_unlock_allowed" "0" 2>/dev/null

    # Fix fingerprint to user (not userdebug)
    local fingerprint
    fingerprint=$($RESETPROP ro.build.fingerprint 2>/dev/null)
    if [ -n "$fingerprint" ]; then
        local fixed_fingerprint="${fingerprint//userdebug/user}"
        $RESETPROP -n "ro.build.fingerprint" "$fixed_fingerprint" 2>/dev/null
    fi

    # Delete props that shouldn't exist
    $RESETPROP --delete "ro.boot.verifiedbooterror" 2>/dev/null
    $RESETPROP --delete "ro.boot.verifyerrorpart" 2>/dev/null
    $RESETPROP --delete "crashrecovery.rescue_boot_count" 2>/dev/null

    log "Android system properties spoofed"
}

# ============================================================
# Phase 8: LSPosed Hiding
# ============================================================

apply_lsposed_hiding() {
    log "Applying LSPosed hiding"

    # Hide dex2oat paths
    susfs_add_map "/system/apex/com.android.art/bin/dex2oat"
    susfs_add_map "/system/apex/com.android.art/bin/dex2oat32"
    susfs_add_map "/system/apex/com.android.art/bin/dex2oat64"
    susfs_add_map "/apex/com.android.art/bin/dex2oat"
    susfs_add_map "/apex/com.android.art/bin/dex2oat32"
    susfs_add_map "/apex/com.android.art/bin/dex2oat64"

    log "LSPosed hiding applied"
}

# ============================================================
# Phase 9: Ext4 Loop/JBD2 Hiding
# ============================================================

apply_ext4_loop_hiding() {
    log "Applying ext4 loop/jbd2 hiding"

    # Hide ext4 loops and jbd2 journals
    for device in $(ls -Ld /proc/fs/jbd2/loop*8 2>/dev/null | sed 's|/proc/fs/jbd2/||; s|-8||'); do
        susfs_add_path "/proc/fs/jbd2/${device}-8"
        susfs_add_path "/proc/fs/ext4/${device}"
    done

    # Spoof nlink of /proc/fs/jbd2 to 2
    $SUSFS_BIN add_sus_kstat_statically '/proc/fs/jbd2' 'default' 'default' '2' 'default' 'default' 'default' 'default' 'default' 'default' 'default' 'default' 'default' 2>/dev/null

    log "Ext4 loop/jbd2 hiding applied"
}

# ============================================================
# Main Entry Point
# ============================================================

apply_hiding() {
    local mode="${1:-full}"

    log "Starting SUSFS hiding engine (mode: $mode)"

    # Initialize log
    > "$LOG_FILE" 2>/dev/null

    case "$mode" in
        paths)
            apply_sus_paths
            apply_sus_maps
            ;;
        spoof)
            apply_uname_spoofing
            apply_cmdline_spoofing
            apply_prop_spoofing
            ;;
        mounts)
            apply_mount_hiding
            apply_avc_log_spoofing
            ;;
        lsposed)
            apply_lsposed_hiding
            ;;
        loops)
            apply_ext4_loop_hiding
            ;;
        full)
            apply_sus_paths
            apply_sus_maps
            apply_uname_spoofing
            apply_cmdline_spoofing
            apply_mount_hiding
            apply_avc_log_spoofing
            apply_lsposed_hiding
            apply_ext4_loop_hiding
            apply_prop_spoofing
            ;;
        *)
            echo "Usage: $0 {paths|spoof|mounts|lsposed|loops|full}"
            return 1
            ;;
    esac

    log "SUSFS hiding engine complete"
}

# Run if called directly
if [ "${0##*/}" = "hiding.sh" ] || [ -z "$1" ]; then
    apply_hiding full
fi
