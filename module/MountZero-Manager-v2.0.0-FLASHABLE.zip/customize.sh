#!/system/bin/sh
# MountZero VFS - Installation Script
# NOTE: No SKIPUNZIP — let KSU handle extraction, we just configure.

MODPATH="${0%/*}"

# Detect architecture
if [ -n "$ARCH" ]; then
    case "$ARCH" in
        arm64) ABI=arm64-v8a ;;
        arm)   ABI=armeabi-v7a ;;
        x64)   ABI=x86_64 ;;
        x86)   ABI=x86 ;;
        *)     ABI="" ;;
    esac
else
    case "$(uname -m)" in
        aarch64)       ABI=arm64-v8a ;;
        armv7*|armv8l) ABI=armeabi-v7a ;;
        x86_64)        ABI=x86_64 ;;
        i686|i386)     ABI=x86 ;;
        *)             ABI="" ;;
    esac
fi

MZ_VERSION=$(grep '^version=' "$MODPATH/module.prop" | cut -d= -f2)

ui_print ""
ui_print "==========================================="
ui_print "  🔥 MountZero VFS ${MZ_VERSION} 🔥"
ui_print "==========================================="
ui_print "  📱 VFS path redirection system"
ui_print "  🧩 KSU / APatch Metamodule"
ui_print "  📦 Overlay mount engine"
ui_print "  🛡️  BRENE hiding engine"
ui_print "==========================================="
ui_print ""

# Set permissions for mzctl binary
ui_print "📦 Setting up mzctl binary..."
chmod 755 "$MODPATH/bin/mzctl"
chown root:root "$MODPATH/bin/mzctl"

# Copy mzctl to KernelSU bin directory
mkdir -p /data/adb/ksu/bin
cp -f "$MODPATH/bin/mzctl" /data/adb/ksu/bin/mzctl
chmod 755 /data/adb/ksu/bin/mzctl
chown root:root /data/adb/ksu/bin/mzctl
ui_print "  ✅ mzctl installed to /data/adb/ksu/bin/"

# Copy susfs binary (BRENE SUSFS CLI)
if [ -f "$MODPATH/bin/susfs" ]; then
    cp -f "$MODPATH/bin/susfs" /data/adb/ksu/bin/susfs
    chmod 755 /data/adb/ksu/bin/susfs
    chown root:root /data/adb/ksu/bin/susfs
    # Create symlink for compatibility
    ln -sf /data/adb/ksu/bin/susfs /data/adb/ksu/bin/ksu_susfs 2>/dev/null
    ui_print "  ✅ susfs binary installed"
fi

# Set permissions for all scripts
ui_print "📦 Setting script permissions..."
chmod 755 "$MODPATH"/*.sh
ui_print "  ✅ Scripts ready"

# Set permissions for webroot
chmod -R 755 "$MODPATH/webroot"
chown -R root:root "$MODPATH/webroot"

# Set permissions for sepolicy.rule and module.prop
chmod 644 "$MODPATH/sepolicy.rule"
chmod 644 "$MODPATH/module.prop"
chmod 644 "$MODPATH/custom_sus_path.txt"
chmod 644 "$MODPATH/custom_sus_map.txt"

# Create data directory and initialize config
ui_print "📦 Initializing data directory..."
mkdir -p /data/adb/mountzero
mkdir -p /data/adb/mountzero/logs
echo 0 > /data/adb/mountzero/.bootcount

# Create overlay work/upper directories
mkdir -p /dev/mountzero_work 2>/dev/null
mkdir -p /dev/mountzero_upper 2>/dev/null
ui_print "  ✅ Overlay mount directories created"

# Copy default SUSFS config files
if [ ! -f /data/adb/mountzero/custom_sus_path.txt ]; then
    cp -f "$MODPATH/custom_sus_path.txt" /data/adb/mountzero/
    ui_print "  ✅ Default SUSFS paths configured"
fi
if [ ! -f /data/adb/mountzero/custom_sus_map.txt ]; then
    cp -f "$MODPATH/custom_sus_map.txt" /data/adb/mountzero/
    ui_print "  ✅ Default SUSFS maps configured"
fi

# Initialize config if first install
if [ ! -f /data/adb/mountzero/config.toml ]; then
    ui_print "📝 Initializing default configuration..."
    "$MODPATH/config.sh" init 2>/dev/null
fi

# Import VerifiedBootHash from susfs4ksu if available
VBH_FILE="/data/adb/VerifiedBootHash/VerifiedBootHash.txt"
if [ -f "$VBH_FILE" ]; then
    VBH=$(cat "$VBH_FILE" 2>/dev/null | head -1 | tr -d '[:space:]')
    if [ -n "$VBH" ]; then
        "$MODPATH/config.sh" set brene verified_boot_hash "$VBH" 2>/dev/null
        ui_print "🔑 Imported VerifiedBootHash"
    fi
fi

# Detect and configure mount source
MOUNT_SOURCE=$("$MODPATH/config.sh" source 2>/dev/null)
ui_print "📦 Mount source: $MOUNT_SOURCE"
"$MODPATH/config.sh" set mount mountSource "$MOUNT_SOURCE" 2>/dev/null

# Device language
DEVICE_LANG=$(getprop ro.system.locale 2>/dev/null || getprop persist.sys.locale 2>/dev/null || getprop ro.product.locale 2>/dev/null || echo "en")
LANG_CODE=$(printf '%s' "$DEVICE_LANG" | sed 's/_/-/g')
"$MODPATH/config.sh" set ui language "$LANG_CODE" 2>/dev/null

# Randomize vbmeta_size
VBS=$(( 4096 + ($(od -An -tu1 -N1 /dev/urandom 2>/dev/null || echo 0) % 8) * 1024 ))
"$MODPATH/config.sh" set brene vbmeta_size "$VBS" 2>/dev/null
ui_print "🎲 vbmeta_size randomized: $VBS"

ui_print ""
ui_print "✅ MountZero VFS installed successfully!"
ui_print "🔥 Hot-plug service will start on next boot"
ui_print "🌐 WebUI available in KernelSU manager"
ui_print "📦 Overlay mount engine enabled"
ui_print "🛡️  BRENE hiding engine configured"
ui_print ""
